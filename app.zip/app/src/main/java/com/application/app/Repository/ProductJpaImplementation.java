package com.application.app.Repository;

import com.application.app.Entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductJpaImplementation extends JpaRepository<Product, Long> {
}
