package com.application.app.Repository;

import com.application.app.Entity.Product;
import org.springframework.data.repository.NoRepositoryBean;

import java.util.List;

public interface ProductCustomRepository {
    List<Product> getProducts();

    Product saveProduct(Product product);

    Product updateProduct(Product product);
}
