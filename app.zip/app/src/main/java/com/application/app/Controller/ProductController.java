package com.application.app.Controller;


import com.application.app.Entity.Product;
import com.application.app.Pojo.ApiResponse;
import com.application.app.Services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/v1/products")
public class ProductController {

    @Autowired
    private ProductService productService;

    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    @GetMapping
    public ResponseEntity getProducts(){
        return ResponseEntity.status(200).body(productService.getProducts());
    }

    @PostMapping
    public ResponseEntity insertProduct(@RequestBody @Valid Product product){
        return ResponseEntity.status(200).body(productService.insertProduct(product));
    }
}
