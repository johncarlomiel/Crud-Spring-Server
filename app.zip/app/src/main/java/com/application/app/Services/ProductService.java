package com.application.app.Services;


import com.application.app.Entity.Product;
import com.application.app.Repository.ProductCustomRepository;
import com.application.app.Repository.ProductJpaImplementation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductService {


    @Autowired
    private ProductCustomRepository productCustomRepository;

    public ProductService(@Qualifier("jpa") ProductCustomRepository productCustomRepository) {
        this.productCustomRepository = productCustomRepository;
    }

    public List<Product> getProducts(){

       return productCustomRepository.getProducts();
    }

    public Product insertProduct(Product product){
        return productCustomRepository.saveProduct(product);
    }
}
