package com.application.app.Repository;

import com.application.app.Entity.Product;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository("mysql")
public class Mysqlmpl implements ProductCustomRepository {
    @Override
    public List<Product> getProducts() {
        return null;
    }

    @Override
    public Product saveProduct(Product product) {
        return null;
    }

    @Override
    public Product updateProduct(Product product) {
        return null;
    }
}
