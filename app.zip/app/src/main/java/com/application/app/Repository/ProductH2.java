package com.application.app.Repository;

import com.application.app.Entity.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;
import java.util.Optional;


@Repository("jpa")
public class ProductH2 implements ProductCustomRepository {

    @Autowired
    private ProductJpaImplementation productJpaImplementation;

    public ProductH2(ProductJpaImplementation productJpaImplementation) {
        this.productJpaImplementation = productJpaImplementation;
    }

    @Override
    public List<Product> getProducts() {
            return productJpaImplementation.findAll();
    }

    @Override
    public Product saveProduct(Product product) {
        return productJpaImplementation.save(product);
    }

    @Override
    public Product updateProduct(Product product) {
        return null;
    }
}
